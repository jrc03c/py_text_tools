from setuptools import setup

setup(
    name="py_text_tools",
    version="0.0.2",
    description="some text tools for python",
    url="https://github.com/jrc03c/py_text_tools",
    author="jrc03c",
    author_email="jrc03c@pm.me",
    license="none",
    packages=["py_text_tools"],
    classifiers=["Topic :: Text Processing"],
    include_package_data=True,
)
